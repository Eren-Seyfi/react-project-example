import { Fragment } from "react";

import Örnek2 from "./Örnek_2"

export default function App() {
  return (
    <Fragment>
    <Örnek2 />
    </Fragment>
  );
}

