import { Fragment, useState  } from "react";



export default function Örnek2() {

  const [count, setCount] = useState(15);

  return (
    <Fragment>
      <button onClick={ () => setCount(count + 1)} >Artir</button>
      <h1>{count}</h1>
      <button  onClick={ () => setCount(count - 1)}>Azalt</button>
    </Fragment>
  );
}
