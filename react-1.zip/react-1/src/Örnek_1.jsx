import { Fragment } from "react";



export default function Örnek1() {
  return (
    <Fragment>
      <h1>Kişi</h1>
      <Kişi isim="Eren" soyisim="Seyfi" /> <br />
      <Kişi2 isim="Beyzanur" soyisim="Seyfi" />

    </Fragment>
  );
}

function Kişi({ isim, soyisim }) {

  return <Fragment>{isim +" " + soyisim}</Fragment>;

}

function Kişi2(props) {
  return <Fragment>{props.isim +" " + props.soyisim}</Fragment>;
}