import { Fragment, useState } from "react";

export default function Show() {
  const [show, setShow] = useState(true);

  return (
    <Fragment>
      <button
        onClick={() => {
          setShow(!show);
        }}
      >
        {show ? "Gizle" : "Göster"}
      </button>
      {show ? (
        <div
          style={{ width: "300px", height: "300px", backgroundColor: "red" }}
        />
      ) : null}
    </Fragment>
  );
}
