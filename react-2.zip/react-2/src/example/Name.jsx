import { Fragment, useState } from "react";

export default function Name() {
  const [name, setName] = useState("");
  const [password, setPassword] = useState("");
  

  return (
    <Fragment>

Username:<input type="text" onChange={ (event)=>{ setName(event.target.value)} } /> <br />
Password:<input type="password" onChange={ (event)=>{ setPassword(event.target.value)} } /> <br />
<button onClick={ ()=>{name != 0 & password != 0 ? alert("Username:"+name+" "+"password:"+password) :null} }>Girişyap</button>



    </Fragment>
  );
}
