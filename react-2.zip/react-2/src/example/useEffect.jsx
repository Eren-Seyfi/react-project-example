import { Fragment, useState, useEffect } from "react";

export default function UseEffect() {
  const [show, setShow] = useState(true);

  useEffect(() => {
    console.log("Tetiklendim");
  },[]);

  useEffect(() => {
    console.log("Tetiklendim 2");
  });

  useEffect(() => {
    console.log("Tetiklendim 3");
  },[""]);


  return (
    <Fragment>
      <button div="tetikle" >Tetikle</button>
      <button
        onClick={() => {
          setShow(!show);
        }}
      >
        {show ? "Gizle" : "Göster"}
      </button>
      {show ? (
        <div
          className="tetiklendi"
          style={{ width: "300px", height: "300px", backgroundColor: "red" }}
        />
      ) : null}
    </Fragment>
  );
}
