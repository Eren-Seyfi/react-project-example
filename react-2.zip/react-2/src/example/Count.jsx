import { Fragment, useState } from "react";

export default function Count() {
  const [count, setCount] = useState(0);

  return (
    <Fragment>
      <div
        style={{
          display: "flex",
          justifyContent: "center",
          alignItems: "center",
        }}
      >

        <button onClick={ () => { setCount(count+1)}} >+</button>
        <p style={{ margin:"10px" }}  > {count}</p>
        <button onClick={ ()=> { setCount(count-1)}}>-</button>
        
      </div>

    </Fragment>
  );
}
