import { Fragment } from "react";

import Name from "./example/Name";
import Show from "./example/Show";
import UseEffect from "./example/useEffect";

export default function App() {
  return (
    <Fragment>
      <UseEffect />
    </Fragment>
  );
}
