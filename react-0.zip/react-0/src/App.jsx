import { Fragment, useState } from "react";

import { Routes, Route, NavLink, Link } from "react-router-dom";
import Home from "./page/Home";
import Login from "./page/Login";
import Ekle from "./page/Ekle";
import Error from "./page/Error";
import _Navbar from "./components/Navbar";
import "./App.css";

export default function App() {
  return (
    <Fragment>
      <_Navbar />
      <br />
      <Routes>
        <Route  path="/" element={<Home />}>
          <Route index path="ekle" element={<Ekle />} />
        </Route>

        <Route path="login" element={<Login />} />
        <Route path="*" element={<Error />} />
      </Routes>
    </Fragment>
  );
}
