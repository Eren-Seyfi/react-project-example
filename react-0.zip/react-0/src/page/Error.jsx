import { Fragment, useState } from 'react'
import {  } from "react-bootstrap"
import {  } from "react-router-dom";

export default function Error() {


  return (
<Fragment>
  
Error 404 page


</Fragment>
  )
}


