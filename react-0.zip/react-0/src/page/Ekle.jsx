import { Fragment, useState } from "react";
import {} from "react-bootstrap";
import { useParams } from "react-router-dom";
export default function Ekle() {
  let params = useParams();

  return (
    <Fragment>
      Ekle page <h1>{params.postId}</h1>
    </Fragment>
  );
}
