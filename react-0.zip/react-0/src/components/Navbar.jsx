import { Fragment, useState } from "react";

import { NavLink } from "react-router-dom";
export default function _Navbar() {
  return (
    <Fragment>
      <NavLink to="login">Login Sayfasi</NavLink>{" "}
      <NavLink to="/">Home Sayfasi</NavLink>{" "}
      <NavLink to="ekle">ekle Sayfasi</NavLink> {" "}
    </Fragment>
  );
}
